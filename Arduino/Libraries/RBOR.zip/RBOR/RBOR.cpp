﻿/*
 * File       Class for control Ryan Baker Octopod Robot
 * Author     Ethan Pan @ Freenove (support@freenove.com)
 * Date       2019/09/04
 * Copyright  Copyright © Freenove (http://www.freenove.com)
 * License    Creative Commons Attribution ShareAlike 3.0
 *            (http://creativecommons.org/licenses/by-sa/3.0/legalcode)
 * -----------------------------------------------------------------------------------------------*/

#if defined(ARDUINO_AVR_MEGA2560)

#include "RBOR.h"

RBOR::RBOR() {}

void RBOR::Start(bool commFunction)
{
  communication.Start(commFunction);
}

void RBOR::Update()
{
  if (communication.commFunction)
    communication.UpdateOrder();
}

void RBOR::SetWiFi(String name, String password)
{
  communication.SetWiFi(name, password);
}

void RBOR::SetWiFiChannel(byte channel)
{
  communication.SetWiFiChannel(channel);
}

void RBOR::SetRC(byte byte0, byte byte1, byte byte2, byte byte3, byte byte4)
{
  communication.SetRC(byte0, byte1, byte2, byte3, byte4);
}

void RBOR::ActiveMode()
{
  if (!communication.commFunction)
    communication.robotAction.ActiveMode();
}

void RBOR::SleepMode()
{
  if (!communication.commFunction)
    communication.robotAction.SleepMode();
}

void RBOR::SwitchMode()
{
  if (!communication.commFunction)
    communication.robotAction.SwitchMode();
}

void RBOR::CrawlForward()
{
  if (!communication.commFunction)
    communication.robotAction.CrawlForward();
}

void RBOR::CrawlBackward()
{
  if (!communication.commFunction)
    communication.robotAction.CrawlBackward();
}

void RBOR::CrawlLeft()
{
  if (!communication.commFunction)
    communication.robotAction.CrawlLeft();
}

void RBOR::CrawlRight()
{
  if (!communication.commFunction)
    communication.robotAction.CrawlRight();
}

void RBOR::TurnLeft()
{
  if (!communication.commFunction)
    communication.robotAction.TurnLeft();
}

void RBOR::TurnRight()
{
  if (!communication.commFunction)
    communication.robotAction.TurnRight();
}

void RBOR::Crawl(float x, float y, float angle)
{
  if (!communication.commFunction)
    communication.robotAction.Crawl(x, y, angle);
}

void RBOR::MoveBody(float x, float y, float z)
{
  if (!communication.commFunction)
    communication.robotAction.MoveBody(x, y, z);
}

void RBOR::RotateBody(float x, float y, float z)
{
  if (!communication.commFunction)
    communication.robotAction.RotateBody(x, y, z);
}

void RBOR::TwistBody(float xMove, float yMove, float zMove, float xRotate, float yRotate, float zRotate)
{
  if (!communication.commFunction)
    communication.robotAction.TwistBody(Point(xMove, yMove, zMove), Point(xRotate, yRotate, zRotate));
}

void RBOR::LegMoveToRelatively(int leg, float x, float y, float z)
{
  if (!communication.commFunction)
    communication.robotAction.LegMoveToRelatively(leg, Point(x, y, z));
}

void RBOR::SetActionGroup(int group)
{
  if (!communication.commFunction)
    communication.robotAction.SetActionGroup(group);
}

#endif
